DROP SCHEMA IF EXISTS valid_data;
DROP SCHEMA IF EXISTS invalid_data;

CREATE SCHEMA valid_data;
CREATE SCHEMA invalid_data;
