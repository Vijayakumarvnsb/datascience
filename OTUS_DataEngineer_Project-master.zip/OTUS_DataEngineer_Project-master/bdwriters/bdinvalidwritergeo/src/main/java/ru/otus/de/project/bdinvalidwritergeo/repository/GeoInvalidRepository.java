package ru.otus.de.project.bdinvalidwritergeo.repository;

import org.springframework.data.repository.CrudRepository;
import ru.otus.de.project.bdinvalidwritergeo.Entity.GeoInvalid;

public interface GeoInvalidRepository extends CrudRepository<GeoInvalid, Long> {

}
