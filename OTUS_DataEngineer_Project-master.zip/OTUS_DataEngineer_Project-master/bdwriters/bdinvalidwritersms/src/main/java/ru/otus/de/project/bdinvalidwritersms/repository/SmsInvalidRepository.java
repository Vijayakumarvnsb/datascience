package ru.otus.de.project.bdinvalidwritersms.repository;

import org.springframework.data.repository.CrudRepository;
import ru.otus.de.project.bdinvalidwritersms.entity.SmsInvalid;

public interface SmsInvalidRepository extends CrudRepository<SmsInvalid, Long> {

}
