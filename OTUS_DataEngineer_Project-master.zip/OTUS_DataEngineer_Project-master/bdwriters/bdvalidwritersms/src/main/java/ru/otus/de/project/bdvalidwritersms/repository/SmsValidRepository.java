package ru.otus.de.project.bdvalidwritersms.repository;

import org.springframework.data.repository.CrudRepository;
import ru.otus.de.project.bdvalidwritersms.entity.SmsValid;

public interface SmsValidRepository extends CrudRepository<SmsValid, Long> {

}
