package ru.otus.de.project.bdvalidwritergeo.repository;

import org.springframework.data.repository.CrudRepository;
import ru.otus.de.project.bdvalidwritergeo.Entity.GeoValid;

public interface GeoValidRepository extends CrudRepository<GeoValid, Long> {

}
