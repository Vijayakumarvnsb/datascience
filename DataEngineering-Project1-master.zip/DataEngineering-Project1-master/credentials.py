USER = 'student' # add your postgresql db name user here
PASSWORD = 'student' # add your postgresql db password here